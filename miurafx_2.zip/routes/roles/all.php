<?php

// MASTER MONITOR ACCESOR CLIENTE - ALL

use App\Http\Controllers\ClienteController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:sanctum', 'role:master|monitor|accesor|cliente'])->group(function () {
    // clientes -> show,
    Route::apiResource('clientes', ClienteController::class)->only('show');
});
